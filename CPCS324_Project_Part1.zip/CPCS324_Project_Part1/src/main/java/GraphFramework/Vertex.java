
package GraphFramework;

import java.util.LinkedList;


public class Vertex {
  
    private int label; //value of vertex
    private boolean isVisited= false;  //check if vertex visited
    private LinkedList<Edge> adjList;  //store adjacent list of each vertex
    
    
    public Vertex() {
        adjList = new LinkedList<Edge>() ;
    }
    public Vertex(int label) {
        this.label = label;
        this.isVisited = false;
        adjList = new LinkedList<Edge>();
      
    }
    public int getLabel() {
        return label;
    }
    public void setLabel(int label) {
        this.label = label;
    }

    public boolean isIsVisited() {
        return isVisited;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    public LinkedList<Edge> getAdjList() {
        return adjList;
    }

    public void displayInfo(){
      System.out.println(label);//display vertex label 
    }
}
