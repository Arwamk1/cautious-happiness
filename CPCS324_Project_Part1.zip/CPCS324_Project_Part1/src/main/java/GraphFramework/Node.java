
package GraphFramework;

public class Node {
    
    String data;
    int rank;
    Node parent;

}
