
package GraphFramework;

import java.util.LinkedList;



public class MSTalgorithm {
 Edge [] MSTresultList;

    public MSTalgorithm() {
    Edge [] MSTresultList =   this.MSTresultList;
    }
    

    public void findMST(Graph Graph) {
    }

    public void displayResultingMST() {

    } 

    public void displayMSTcost() {
        
    }
}
 
  


