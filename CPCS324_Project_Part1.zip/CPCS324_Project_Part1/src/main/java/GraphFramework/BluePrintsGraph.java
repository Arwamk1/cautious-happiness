
package GraphFramework;

import PhoneNetworkApp.Line;
import PhoneNetworkApp.Office;

public  class BluePrintsGraph extends Graph {

    public BluePrintsGraph() {
    }
    
    
    public BluePrintsGraph(int veticeNo, int edgeNo, boolean isDigraph) {
        super(veticeNo, edgeNo, isDigraph);
    }

    @Override
    public Vertex createVertex(int label) {
        return new Office(label); //to create obj. of office
    }

@Override
    public Edge createEdge(Vertex source, Vertex target, int wieght) {
        return new Line(source, target, wieght); //to create obj. of line
    }
 
}

    
    
    
    
    

