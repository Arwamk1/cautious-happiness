package GraphFramework;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

public class KruskalAlg extends MSTalgorithm {
   // Data fields

    private int cost = 0; //cost of MST

   
    public KruskalAlg(Graph graph) {
        MSTresultList = new Edge[graph.getVerticesNo()]; // MST List
    }

    /**
     * Shows Resulting MST
     */
    public void findMST(Graph graph) {

        Vertex vSource; // Vertex source
        Vertex vTarget; // Vertex target
        Edge edge; // Vertex edge

        ArrayList<Edge> edges = new ArrayList<Edge>(); // to store edges weights

        // Loop through ALL vertices
        for (int i = 0; i < graph.getVerticesNo(); i++) {
            vSource = graph.getVertices()[i];
            
            // Loop through adjacent list of this vertex
            for (int j = 0; j < vSource.getAdjList().size(); j++) {
                edges.add(vSource.getAdjList().get(j));
              
            } // end of inner for-loop
        } // end of outer for-loop

       
        // 1. (MakeSet) Make Set for Each Vertex
        Vertex[] findEdgeList = new Vertex[graph.getVerticesNo()]; // Set the DS as the number of vertices 
        // this loop used to create one-element set{x} for all the V in the graph 
        for (int i = 0; i < findEdgeList.length; i++) {
            findEdgeList[i] = new Vertex(i);
            
        }
       // Make set for each vertex
        int encounter = 0;
        int countOfEdge = 0;
        // Loop through ALL edges
        while (encounter < MSTresultList.length - 1) {

            // Get Minimum-weight Edge & its source & target
            edge = edges.get(countOfEdge);
            vSource = edge.getSource();
            vTarget = edge.getTarget();


            // 2. (findSet)Find Representative Subset from the QuickFind Disjoint Sets
            if (!findSet(findEdgeList[vSource.getLabel()].getLabel(), findEdgeList[vTarget.getLabel()].getLabel())) {

                // 3. (Union) Append VT to VU & and update their representative value; 
                union(findEdgeList, vSource, vTarget);

                MSTresultList[encounter] = edge; // Add the target edge to the MST list	 
                cost += MSTresultList[encounter].getWeight(); // Get cost of minimum-weight edges (MST)

                encounter++; // increment number of edges encountered
            }
            countOfEdge++;// End of if-statement
        } // End of while-loop

    } // End of Method

    
    public boolean findSet(int v1, int v2) {
     
        return v1 == v2;
    } // End of FindSet Method

    
    public void union(Vertex[] findEdgeList, Vertex vSource, Vertex vTarget) {
        int vSourceRep = findEdgeList[vSource.getLabel()].getLabel(); // get VV representative 
        int vTargetRep = findEdgeList[vTarget.getLabel()].getLabel(); // get VU representative

        boolean vSourceNoRep = findSet(vSource.getLabel(), vSourceRep); // Find if VV have representative or not
        boolean vTargetNoRep = findSet(vTarget.getLabel(), vTargetRep); // Find if VU have representative or not
       
       

        // Check if current VV & VU are representative of set 
        int counter = 0;
        while (counter < findEdgeList.length) {
            // Check the (quickFindDs array if VV is representative of other vertex) && (excluding their own)
            if (vSourceRep == findEdgeList[counter].getLabel() && (counter != vSource.getLabel())) {

                vSourceNoRep = false; // false when VV have itself is other vertex representative
            } // End of if-statement
            // Check the (quickFindDs array if VU is representative of other vertex) && (excluding their own)
            if (vTargetRep == findEdgeList[counter].getLabel() && (counter != vTarget.getLabel())) {
                vTargetNoRep = false; // false when VV have itself is other vertex representative

            }
            counter++;// End of if-statement
        }
        // End of for-loop

        // if VV have -a- representative and VU have -no- representative OR VV & VU (both) have -no- representative
        if (((!vSourceNoRep) && (vTargetNoRep)) || (vSourceNoRep && vTargetNoRep)) {

            // Make VV is the new representative
            findEdgeList[vSource.getLabel()] = findEdgeList[vSource.getLabel()];
            findEdgeList[vTarget.getLabel()] = findEdgeList[vSource.getLabel()];
        } // End of if-statement
        // if VV have -no- representative and VU have -a- representative
        else if (vSourceNoRep && (!vTargetNoRep)) {
            findEdgeList[vSource.getLabel()] = findEdgeList[vTarget.getLabel()];
        } // End of else-if
        // VV & VU (both) have -a- representative
        else {

            int maxRep = Math.max(vSourceRep, vTargetRep); // Get max representative to overwrite its children
            int minRep = Math.min(vSourceRep, vTargetRep); // Get minimum to set it as the new representative

            // Loop through the QuickFind Disjoint Subset
            for (int i = 0; i < findEdgeList.length; i++) {

                // Find all the children of the max representative
                if (findEdgeList[i].getLabel() == maxRep) {
                    findEdgeList[i] = findEdgeList[minRep]; // Update all representatives to the minimum Representative

                } // End of if-statement
            } // End of for-loop
        } // End of else

    } // End of Union method

    public void displayResultingMST() {
        for (int i = 0; i < MSTresultList.length - 1; i++) {
            Vertex vf = MSTresultList[i].getSource();
           
            vf.displayInfo(); //display source info.
            System.out.print(" - ");
            Vertex vs = MSTresultList[i].getTarget();
            vs.displayInfo();  //display target info.
            System.out.print("");
            Edge e = MSTresultList[i];
            e.displayInfo(); //display edge weight
            System.out.println();
        }
        
    }

 
    
    public void displayMSTcost() {
        System.out.println("The cost of designed phone network: " + this.cost);//final cost of MST
    }
} // End of Class