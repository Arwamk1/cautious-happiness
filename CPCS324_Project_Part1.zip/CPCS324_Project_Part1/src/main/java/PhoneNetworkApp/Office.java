package PhoneNetworkApp;

import GraphFramework.Vertex;

public class Office extends Vertex {

    // Data Fields
    private String OfficeNo; //label of vertex

    public Office(int label) {
        super(label);
        this.OfficeNo = String.valueOf((char) (label + 65));
    }
    
    // print office info.
    @Override
    public void displayInfo() {
        System.out.print("Office No. " + OfficeNo); 
    } // End of method

} // End of class
