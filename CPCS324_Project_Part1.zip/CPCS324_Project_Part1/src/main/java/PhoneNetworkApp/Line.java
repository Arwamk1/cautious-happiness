
package PhoneNetworkApp;
import GraphFramework.Edge;
import GraphFramework.Vertex;

public class Line extends Edge {
    
    // Data Fields
    private int lineLength; //weight of edge

    public Line(Vertex source, Vertex target, int weight) {
        super(source, target, weight);
        this.lineLength = weight;
    } // End of Method

    // // print line info.
    @Override
    public void displayInfo() {
        System.out.print(" : line length: " + lineLength);
    } // End of Method

} // End of Class
